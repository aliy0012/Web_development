<html>
	<head>
		<title>Lab6</title>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
	<body>
		<?php
			include_once "header.php";
      include_once "menu.php";
			include_once "ChessBoard.php";
			include_once "footer.php";
		?>
	</body>
</html>
