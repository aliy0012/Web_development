<?php
	echo "<div id=\"content\">";
	echo ' <a href="Chess.php">ChessBoard</a>';
  echo "<br/>";
  echo ' <a href="primer.php">Prime</a>';
  echo "<br/>";
  echo ' <a href="patterner.php">Pattern</a>';
	echo "</div>";

	echo "</div>";
?>
