<?php
	echo "<div id=\"menu\">";
	echo "<h3>Menu</h3>";

  echo ' <a href="Chess.php">ChessBoard</a>';
  echo "<br/>";
  echo ' <a href="primer.php">Prime</a>';
  echo "<br/>";
  echo ' <a href="patterner.php">Pattern</a>';
	echo "</div>";
?>
