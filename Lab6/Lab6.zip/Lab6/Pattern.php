	<?php

				echo "<div id=\"content\">";
			  $i=0;
			  for($i=1; $i<6; $i++){
			    echo "*";
			  }
			  echo "</br/>";
			  for($i=1; $i<6; $i++){
			    if($i == 1 || $i ==5){
			      echo "*";
			    }else {
			      echo str_repeat('&nbsp;', 2);
			    }
			  }
			  echo "</br/>";
			  for($i=1; $i<6; $i++){
			    if($i == 1 || $i ==5){
			      echo "*";
			    }else {
			      echo str_repeat('&nbsp;', 2);
			    }
			  }
			  echo "</br/>";
			  for($i=1; $i<6; $i++){
			    if($i == 1 || $i ==5){
			      echo "*";
			    }else {
			      echo str_repeat('&nbsp;', 2);
			    }
			  }
			  echo "</br/>";
			  for($i=1; $i<6; $i++){
			    echo "*";
			  }

				echo "</div>";

		?>
