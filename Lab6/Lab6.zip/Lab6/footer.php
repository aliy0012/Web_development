<?php
	echo "<div id=\"footer\">Ali Aliyev   041013372    aliy0012@algonquinlive.com</div>";
?>
