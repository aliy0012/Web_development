<html>
	<head>
		<title>Include Example</title>
		<link rel="stylesheet" type="text/css" href="StyleSheet.css" />
	</head>
	<body>
		<?php
			include_once "header.php";
      include_once "menu.php";
			include_once "content.php";
			include_once "footer.php";
		?>
	</body>
</html>
