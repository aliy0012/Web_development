<?php
	echo "<div id=\"content\">";
	$firstName = "Ali";
  $lastName ="Aliyev";
  define("studentNo", "041013373");

  echo "<br/>";
  echo "<br/>";
  echo "<br/>";
  $first = "Hello World!!";
  $second = "This is the fist time I am using PHP!!";
  echo $first  . $second ;
  echo "<br/>";

	echo "</div>";
?>
