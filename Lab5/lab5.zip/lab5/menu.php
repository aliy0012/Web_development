<?php
	echo "<div id=\"menu\">";
	echo "<h3>Menu</h3>";

  echo ' <a href="http://alia.sgedu.site/lab2.html">Lab2</a>';
  echo "<br/>";
  echo ' <a href="http://alia.sgedu.site/">Lab3</a>';
  echo "<br/>";
  echo ' <a href="http://alia.sgedu.site/Lab4.html">Lab4</a>';
	echo "</div>";
?>
